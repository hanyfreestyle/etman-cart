-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 21, 2023 at 10:38 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `a_etman`
--

-- --------------------------------------------------------

--
-- Table structure for table `attribute_tables`
--

CREATE TABLE `attribute_tables` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attribute_tables`
--

INSERT INTO `attribute_tables` (`id`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, '2023-08-21 17:12:44', '2023-08-21 17:12:44'),
(2, 1, NULL, '2023-08-21 17:12:56', '2023-08-21 17:12:56'),
(3, 1, NULL, '2023-08-21 17:13:11', '2023-08-21 17:13:11'),
(4, 1, NULL, '2023-08-21 17:13:28', '2023-08-21 17:13:28'),
(5, 1, NULL, '2023-08-21 17:13:39', '2023-08-21 17:13:39'),
(6, 1, NULL, '2023-08-21 17:19:50', '2023-08-21 17:19:50'),
(7, 1, NULL, '2023-08-21 17:25:22', '2023-08-21 17:25:22'),
(8, 1, NULL, '2023-08-21 17:27:58', '2023-08-21 17:27:58'),
(9, 1, NULL, '2023-08-21 17:28:18', '2023-08-21 17:28:18'),
(10, 1, NULL, '2023-08-21 17:29:58', '2023-08-21 17:29:58');

-- --------------------------------------------------------

--
-- Table structure for table `attribute_table_translations`
--

CREATE TABLE `attribute_table_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attribute_table_translations`
--

INSERT INTO `attribute_table_translations` (`id`, `attribute_id`, `locale`, `name`) VALUES
(1, 1, 'ar', 'نوع المادة اللاصقة'),
(2, 1, 'en', 'Type Of Adhesive'),
(3, 2, 'ar', 'الفيلم'),
(4, 2, 'en', 'Film'),
(5, 3, 'ar', 'العرض'),
(6, 3, 'en', 'Width'),
(7, 4, 'ar', 'الطول'),
(8, 4, 'en', 'Length'),
(9, 5, 'ar', 'سماكة'),
(10, 5, 'en', 'Thickness'),
(11, 6, 'ar', 'التغليف'),
(12, 6, 'en', 'Packaging'),
(13, 7, 'ar', 'الكور'),
(14, 7, 'en', 'Core'),
(15, 8, 'ar', 'سبيكة'),
(16, 8, 'en', 'Alloy'),
(17, 9, 'ar', 'السطح'),
(18, 9, 'en', 'Surface Finishing'),
(19, 10, 'ar', 'وحدة البيع'),
(20, 10, 'en', 'Sale Unit');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `photo`, `photo_thum_1`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, NULL, 'images/category/1/self-adhesive-tape.webp', 'images/category/1/self-adhesive-tape_0.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:12:19'),
(3, 1, 'images/category/3/self-adhesive-tape-packaging-tape.webp', 'images/category/3/self-adhesive-tape-packaging-tape_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:00'),
(6, 1, 'images/category/6/self-adhesive-tape-stationary-tape.webp', 'images/category/6/self-adhesive-tape-stationary-tape_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:07'),
(7, 1, 'images/category/7/self-adhesive-tape-masking-tape.webp', 'images/category/7/self-adhesive-tape-masking-tape_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:10'),
(10, 1, 'images/category/10/self-adhesive-tape-electrical-insulating-tape.webp', 'images/category/10/self-adhesive-tape-electrical-insulating-tape_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:13'),
(12, 1, 'images/category/12/self-adhesive-tape-double-sided-tape.webp', 'images/category/12/self-adhesive-tape-double-sided-tape_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:16'),
(13, 1, 'images/category/13/self-adhesive-color-tape.webp', 'images/category/13/self-adhesive-color-tape_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:18'),
(14, 1, 'images/category/14/printed-self-adhesive-tape.webp', 'images/category/14/printed-self-adhesive-tape_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:21'),
(15, NULL, 'images/category/15/aluminum-foil.webp', 'images/category/15/aluminum-foil_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:24'),
(16, 15, 'images/category/16/aluminium-foil-for-industry-use.webp', 'images/category/16/aluminium-foil-for-industry-use_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:27'),
(17, 15, 'images/category/17/aluminium-foil-for-house-hold.webp', 'images/category/17/aluminium-foil-for-house-hold_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:30'),
(18, NULL, 'images/category/18/food-and-beverage.webp', 'images/category/18/food-and-beverage_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:33'),
(19, 18, 'images/category/19/cling-warp.webp', 'images/category/19/cling-warp_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:35'),
(23, NULL, 'images/category/23/decorative-strips.webp', 'images/category/23/decorative-strips_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:38'),
(24, 23, 'images/category/24/gift-accessories-ribbon.webp', 'images/category/24/gift-accessories-ribbon_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:40'),
(25, 23, 'images/category/25/gift-accessories-gift-paper.webp', 'images/category/25/gift-accessories-gift-paper_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:43'),
(26, 23, 'images/category/26/gift-accessories-crepe-paper.webp', 'images/category/26/gift-accessories-crepe-paper_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:46'),
(36, 1, 'images/category/36/self-adhesive-tape-laser-tape.webp', 'images/category/36/self-adhesive-tape-laser-tape_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:49'),
(37, 1, 'images/category/37/jumbo-roll.webp', 'images/category/37/jumbo-roll_1.webp', 1, NULL, '2023-08-20 13:21:00', '2023-08-20 15:14:52');

-- --------------------------------------------------------

--
-- Table structure for table `category_tables`
--

CREATE TABLE `category_tables` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `attribute_id` int(11) DEFAULT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_tables`
--

INSERT INTO `category_tables` (`id`, `category_id`, `attribute_id`, `postion`, `created_at`, `updated_at`) VALUES
(1, 6, 1, 0, '2023-08-21 17:16:19', '2023-08-21 17:16:19'),
(2, 6, 2, 0, '2023-08-21 17:16:36', '2023-08-21 17:16:36'),
(3, 6, 3, 0, '2023-08-21 17:16:54', '2023-08-21 17:16:54'),
(4, 6, 4, 0, '2023-08-21 17:17:06', '2023-08-21 17:17:06'),
(5, 6, 5, 0, '2023-08-21 17:17:21', '2023-08-21 17:17:21'),
(6, 10, 1, 0, '2023-08-21 17:18:40', '2023-08-21 17:18:40'),
(7, 10, 2, 0, '2023-08-21 17:18:56', '2023-08-21 17:18:56'),
(8, 10, 3, 0, '2023-08-21 17:19:09', '2023-08-21 17:19:09'),
(9, 10, 4, 0, '2023-08-21 17:19:28', '2023-08-21 17:19:28'),
(10, 10, 6, 0, '2023-08-21 17:20:10', '2023-08-21 17:20:10'),
(11, 12, 1, 0, '2023-08-21 17:21:09', '2023-08-21 17:21:09'),
(12, 12, 2, 0, '2023-08-21 17:21:19', '2023-08-21 17:21:19'),
(13, 12, 3, 0, '2023-08-21 17:21:30', '2023-08-21 17:21:30'),
(14, 12, 4, 0, '2023-08-21 17:22:06', '2023-08-21 17:22:06'),
(15, 12, 5, 0, '2023-08-21 17:22:20', '2023-08-21 17:22:20'),
(16, 13, 1, 0, '2023-08-21 17:23:28', '2023-08-21 17:23:28'),
(17, 13, 2, 0, '2023-08-21 17:23:39', '2023-08-21 17:23:39'),
(18, 13, 3, 0, '2023-08-21 17:23:50', '2023-08-21 17:23:50'),
(19, 13, 4, 0, '2023-08-21 17:24:01', '2023-08-21 17:24:01'),
(20, 13, 5, 0, '2023-08-21 17:24:15', '2023-08-21 17:24:15'),
(21, 14, 1, 0, '2023-08-21 17:25:53', '2023-08-21 17:25:53'),
(22, 14, 2, 0, '2023-08-21 17:26:05', '2023-08-21 17:26:05'),
(23, 14, 3, 0, '2023-08-21 17:26:19', '2023-08-21 17:26:19'),
(24, 14, 4, 0, '2023-08-21 17:26:31', '2023-08-21 17:26:31'),
(25, 14, 5, 0, '2023-08-21 17:26:44', '2023-08-21 17:26:44'),
(26, 14, 7, 0, '2023-08-21 17:26:57', '2023-08-21 17:26:57'),
(27, 16, 5, 0, '2023-08-21 17:28:40', '2023-08-21 17:28:40'),
(28, 16, 8, 0, '2023-08-21 17:28:55', '2023-08-21 17:28:55'),
(29, 16, 9, 0, '2023-08-21 17:29:06', '2023-08-21 17:29:06'),
(30, 17, 5, 0, '2023-08-21 17:30:28', '2023-08-21 17:30:28'),
(31, 17, 8, 0, '2023-08-21 17:30:38', '2023-08-21 17:30:38'),
(32, 17, 9, 0, '2023-08-21 17:30:52', '2023-08-21 17:30:52'),
(33, 17, 10, 0, '2023-08-21 17:31:06', '2023-08-21 17:31:06'),
(34, 25, 5, 0, '2023-08-21 17:31:55', '2023-08-21 17:31:55'),
(35, 25, 4, 0, '2023-08-21 17:32:07', '2023-08-21 17:32:07'),
(36, 25, 3, 0, '2023-08-21 17:32:23', '2023-08-21 17:32:23'),
(37, 36, 1, 0, '2023-08-21 17:33:38', '2023-08-21 17:33:38'),
(38, 36, 2, 0, '2023-08-21 17:33:49', '2023-08-21 17:33:49'),
(39, 36, 3, 0, '2023-08-21 17:34:02', '2023-08-21 17:34:02'),
(40, 36, 4, 0, '2023-08-21 17:34:15', '2023-08-21 17:34:15'),
(41, 36, 5, 0, '2023-08-21 17:34:30', '2023-08-21 17:34:30'),
(42, 37, 1, 0, '2023-08-21 17:35:10', '2023-08-21 17:35:10'),
(43, 37, 3, 0, '2023-08-21 17:35:22', '2023-08-21 17:35:22'),
(44, 37, 4, 0, '2023-08-21 17:35:34', '2023-08-21 17:35:34'),
(45, 37, 5, 0, '2023-08-21 17:35:49', '2023-08-21 17:35:49'),
(46, 37, 7, 0, '2023-08-21 17:36:03', '2023-08-21 17:36:03');

-- --------------------------------------------------------

--
-- Table structure for table `category_table_translations`
--

CREATE TABLE `category_table_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_table_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_table_translations`
--

INSERT INTO `category_table_translations` (`id`, `category_table_id`, `locale`, `name`, `des`) VALUES
(1, 1, 'ar', NULL, 'لاصق أكريليك ذو أساس مائي'),
(2, 1, 'en', NULL, 'Water based acrylic adhesive'),
(3, 2, 'ar', NULL, 'شفاف ، كريستال ، الوان ، ليزير'),
(4, 2, 'en', NULL, 'clear & crystal film & easy tear film & laser color'),
(5, 3, 'ar', NULL, '12مم ,15مم ,18مم ,24مم'),
(6, 3, 'en', NULL, '12mm ,15mm ,18mm ,24mm'),
(7, 4, 'ar', NULL, '10,12,13.5,25, 30 متر'),
(8, 4, 'en', NULL, '10,12,13.5,25, 30 meters'),
(9, 5, 'ar', NULL, '38 & 40 ميكرون'),
(10, 5, 'en', NULL, '38 & 40 Micron'),
(11, 6, 'ar', NULL, 'لاصق مطاطى'),
(12, 6, 'en', NULL, 'rubber adhesive'),
(13, 7, 'ar', NULL, 'شريط عازل'),
(14, 7, 'en', NULL, 'insulating tape'),
(15, 8, 'ar', NULL, '18 مم'),
(16, 8, 'en', NULL, '18mm'),
(17, 9, 'ar', NULL, '5,7,10,15,20 يارده'),
(18, 9, 'en', NULL, '5,7,10,15,20 yard'),
(19, 10, 'ar', NULL, '50 عبوة بالكرتونة'),
(20, 10, 'en', NULL, '50shrink/CTN'),
(21, 11, 'ar', NULL, 'لاصق مذيب'),
(22, 11, 'en', NULL, 'Solvent adhesive'),
(23, 12, 'ar', NULL, 'شريط ورقى'),
(24, 12, 'en', NULL, 'tissue tape'),
(25, 13, 'ar', NULL, '12-15-18-24-45 مم'),
(26, 13, 'en', NULL, '12-15-18-24-45mm'),
(27, 14, 'ar', NULL, '10 يارده'),
(28, 14, 'en', NULL, '10 yard'),
(29, 15, 'ar', NULL, '190 ميكرون'),
(30, 15, 'en', NULL, '190 mic'),
(31, 16, 'ar', NULL, 'لاصق أكريليك ذو أساس مائي'),
(32, 16, 'en', NULL, 'water based adhesive'),
(33, 17, 'ar', NULL, 'ملون'),
(34, 17, 'en', NULL, 'COLOR'),
(35, 18, 'ar', NULL, 'متاح تحت الطلب'),
(36, 18, 'en', NULL, 'available under request'),
(37, 19, 'ar', NULL, 'متاح تحت الطلب'),
(38, 19, 'en', NULL, 'available under request'),
(39, 20, 'ar', NULL, '45 ميكرون'),
(40, 20, 'en', NULL, '45 mic'),
(41, 21, 'ar', NULL, 'مادة لاصقة ذات أساس مائي'),
(42, 21, 'en', NULL, 'water based adhesive'),
(43, 22, 'ar', NULL, 'شفاف وأبيض'),
(44, 22, 'en', NULL, 'clear & white based'),
(45, 23, 'ar', NULL, 'متاح حسب الطلب'),
(46, 23, 'en', NULL, 'available under request'),
(47, 24, 'ar', NULL, 'متاح حسب الطلب'),
(48, 24, 'en', NULL, 'available under request'),
(49, 25, 'ar', NULL, 'متاح حسب الطلب'),
(50, 25, 'en', NULL, 'available under request'),
(51, 26, 'ar', NULL, 'حسب متطلبات العملاء'),
(52, 26, 'en', NULL, 'clients requirements'),
(53, 27, 'ar', NULL, '0.025 مم - 0.060 مم - 0.080 مم'),
(54, 27, 'en', NULL, '0.025 mm - 0.060 mm - 0.080 mm'),
(55, 28, 'ar', NULL, '8011/ H14'),
(56, 28, 'en', NULL, '8011/ H14'),
(57, 29, 'ar', NULL, 'جانب واحد لامع ، والاخر غير لامع'),
(58, 29, 'en', NULL, 'one side bright, one side matte'),
(59, 30, 'ar', NULL, '0.010 مم - 0.011 مم'),
(60, 30, 'en', NULL, '0.010 mm , 0.011 mm'),
(61, 31, 'ar', NULL, '8011/O'),
(62, 31, 'en', NULL, '8011/O'),
(63, 32, 'ar', NULL, 'جانب واحد لامع ، والاخر غير لامع'),
(64, 32, 'en', NULL, 'one side bright, one side matte'),
(65, 33, 'ar', NULL, 'معبأة في صندوق العرض أو أكياس'),
(66, 33, 'en', NULL, 'Packed in Display box or PP bag'),
(67, 34, 'ar', NULL, '20 ميكرون'),
(68, 34, 'en', NULL, '20 micron'),
(69, 35, 'ar', NULL, '70 سم'),
(70, 35, 'en', NULL, '70 cm'),
(71, 36, 'ar', NULL, '100 سم'),
(72, 36, 'en', NULL, '100 cm'),
(73, 37, 'ar', NULL, 'لاصق أكريليك ذو أساس مائي'),
(74, 37, 'en', NULL, 'water based adhesive'),
(75, 38, 'ar', NULL, 'ليزر'),
(76, 38, 'en', NULL, 'Laser'),
(77, 39, 'ar', NULL, '4.5 سم'),
(78, 39, 'en', NULL, '4.5 cm'),
(79, 40, 'ar', NULL, 'متاح حسب الطلب'),
(80, 40, 'en', NULL, 'as per request'),
(81, 41, 'ar', NULL, '40 ميكرون'),
(82, 41, 'en', NULL, '40 mic'),
(83, 42, 'ar', NULL, 'مادة لاصقة ذات أساس مذيب طبيعي'),
(84, 42, 'en', NULL, 'Water based acrylic adhesive'),
(85, 43, 'ar', NULL, '1280 ,1610 , 1620 mm'),
(86, 43, 'en', NULL, '1280 ,1610 , 1620 mm'),
(87, 44, 'ar', NULL, '4000, 4500, 4800, 7300, 7500 متر'),
(88, 44, 'en', NULL, '4000, 4500, 4800, 7300, 7500 Mtrs'),
(89, 45, 'ar', NULL, '36 ميكرون الى 50 ميكرون'),
(90, 45, 'en', NULL, '36 microns to 50 microns'),
(91, 46, 'ar', NULL, '760 mm'),
(92, 46, 'en', NULL, '760 mm');

-- --------------------------------------------------------

--
-- Table structure for table `category_translations`
--

CREATE TABLE `category_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_h1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `breadcrumb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_translations`
--

INSERT INTO `category_translations` (`id`, `category_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`, `body_h1`, `breadcrumb`, `deleted_at`) VALUES
(1, 1, 'ar', 'الأشرطة-ذاتية-اللصق', 'الأشرطة ذاتية اللصق', 'الأشرطة ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بغشاء BOPP.\r\nإنها مناسبة للاستخدامات المختلفة وفقًا لسمكها. \r\n\r\nإنه لزج (لزج) بدون أي حرارة أو مذيب للتنشيط ويلتصق بضغط خفيف. تتطلب هذه الأشرطة عادةً عامل تحرير على ظهرها أو بطانة تحرير لتغطية المادة اللاصقة.\r\n\r\nنحن ننتج مجموعة متنوعة من المنتجات لتلبية جميع الاحتياجات الخاصة بمتطلبات سوق التعبئة والتغليف للتغليف يمكن تزويده بـ (التصاق عالي ، قابل للطباعة ، مقاوم للعوامل الجوية وقوة شد عالية).\r\n\r\nمن ناحية أخرى ، لدينا قاعدة مذيب من المطاط الطبيعي ، تستخدم للثلاجات والأفران.\r\nوالتى يتم استخدمها  أثناء تصدير الفواكه والخضروات ، وكذلك يتم استخدمها مع درجات الحرارة العالية ودرجة الحرارة المنخفضة للغاية.', 'عتمان جروب متخصصون فى صناعة الأشرطة ذاتية اللصق بجميع انواعها', 'الأشرطة ذاتية اللصق مصنوعة من مادة لاصقة ذات أساس مائي مطلية بغشاء BOPP. إنها مناسبة للاستخدامات المختلفة وفقًا لسمكها. إنه لزج (لزج) بدون أي حرارة أو مذيب ', NULL, NULL, NULL),
(2, 1, 'en', 'Self-Adhesive-Tape', 'Self Adhesive Tape', 'The packing adhesive tapes is made from water based adhesive coated on BOPP film .It suitable for different weight requirement according to its thickness.\r\n\r\nIt is sticky (tacky) without any heat or solvent for activation and adheres with light pressure. These tapes usually require a release agent on their backing or a release liner to cover the adhesive. \r\n\r\nWe produce variety of products to meet all special needs for economical general, medium heavy-duty and special heavy duty packing.\r\n \r\nIt can be provided with (high adhesion, printable, weather-resistance and high tensile strength).\r\n\r\nOn other hand we have Natural rubber solvent base , using for fridges and ovens . \r\nAs we have needs in sealing cartons go with the Refrigeration during export of fruits and vegetable , also use for seal in high temperature and very low temperature .', 'Etman Group specializes in the manufacture of self-adhesive tapes', 'The packing adhesive tapes is made from water based adhesive coated on BOPP film .It suitable for different weight requirement according to its thickness.\r\n', NULL, NULL, NULL),
(3, 3, 'ar', 'الأشرطة-ذاتية-اللصق-شرائط-التعبئة-والتغليف', 'شرائط التعبئة والتغليف', 'الأشرطة ذاتية اللصق المستخدمة للتغليف مصنوعة من مادة لاصقة ذات أساس مائي مطلية بغشاء BOPP.نحن فى عتمان جروب ننتج مجموعة متنوعة من المنتجات لتلبية جميع احتياجات السوق المحلى \r\nتستخدم في المستودعات والمخازن والمصانع وكذلك الاستخدام المنزلي والمكتبي. يمكن استخدام الاشرطة ذاتية اللصق في عمليات نقل الاثاث ، وشركات الشحن ، والبريد ،وكذلك تستخدم فى عمليات تخزين وتنظيم الأدوات المنزلية', 'الأشرطة ذاتية اللصق | شرائط التعبئة والتغليف', 'الأشرطة ذاتية اللصق المستخدمة للتغليف مصنوعة من مادة لاصقة ذات أساس مائي مطلية بغشاء BOPP.نحن ننتج مجموعة متنوعة من المنتجات لتلبية جميع احتياجات السوق المحلى ', NULL, NULL, NULL),
(4, 3, 'en', 'Self-Adhesive-Tape-Packaging-Tape', 'Packaging Tape', 'The self-adhesive tapes used for packing are made of a water-based adhesive that is coated with BOPP film. We produce a variety of products to meet all the needs of the local market. \r\n\r\nApply at the depot, home and office use. The tape could be used for home removals, shipping and mailing, for storing and organizing household items', 'Self Adhesive Tape | Packaging Tape', 'The self-adhesive tapes used for packing are made of a water-based adhesive that is coated with BOPP film. We produce a variety of products to meet all need', NULL, NULL, NULL),
(5, 6, 'ar', 'الأشرطة-ذاتية-اللصق-السوليتب-المكتبى', 'السوليتب المكتبى', 'السوليتب المكتبى مصنوع من مادة لاصقة أكريليك مائية مطلية بأفلام BOOP.\r\nإنه مناسب للاستخدام للصق الورق ، وتغليف الهدايا وتثبيتها ، وهو سهل الاستخدام كما انه يسهل تمزيقه بدون استخدام القطاعات المخصصة لذلك\r\nمتوفر بأحجام وعروض وتصاميم مختلفة لتلبية متطلبات العميل الخاصة.\r\nالاستعمال: تغليف الهدايا ، التعبئة الخفيفة ، والحرف الفنية ، الاستخدام المكتبي ، إصلاح الورق وتقوية المستندات.', 'الأشرطة ذاتية اللصق | السوليتب المكتبى', 'السوليتب المكتبى مصنوع من مادة لاصقة أكريليك مائية مطلية بأفلام BOOP.\r\nإنه مناسب للاستخدام للصق الورق ، وتغليف الهدايا وتثبيتها ، ', NULL, NULL, NULL),
(6, 6, 'en', 'Self-Adhesive-Tape-Stationary-Tape', 'Stationery Tape', 'Stationary tape is made with water based acrylic adhesive coated on BOOP films . \r\nIt’s suitable for paper mending , general sealing , gift wrapping and fixing , also it can be provided as an easy tear that use without dispensers . \r\nAvailable with different sizes, widths and designs to meet the client’s special requirements .\r\nUsage : gift wrapping , light packing , art craft , office use , paper mending and reinforcing documents .', 'Self Adhesive Tape | Stationary Tap', 'Stationary tape is made with water based acrylic adhesive coated on BOOP films . \r\nIt’s suitable for paper mending , general sealing , gift wrapping  ', NULL, NULL, NULL),
(7, 7, 'ar', 'الأشرطة-ذاتية-اللصق-ماسك-تيب', 'ماسك تيب', 'شرائط الماسك تيب مصنوع من خامات ورقية مغطى بمادة لاصقة مطاطية يمكن استخدامها في تطبيقات الحماية والتثبيت والأغراض العامة. إنه متوفر بأحجام مختلفة لتلبية متطلبات العميل الخاصة. تستخدم بدرجات حرارة مختلفة للدهان السيارات. وتغطية الأسطح أثناء الرش أو الطلاء. وكذلك حماية الأسطح المعدنية والبلاستيكية والزجاجية.', 'الأشرطة ذاتية اللصق | ماسك تيب تستخدم لاغراض الحماية والتثبيت', 'شرائط الماسك تيب مصنوع من خامات ورقية مغطى بمادة لاصقة مطاطية يمكن استخدامها في تطبيقات الحماية والتثبيت والأغراض العامة. إنه متوفر بأحجام مختلفة ', NULL, NULL, NULL),
(8, 7, 'en', 'Self-Adhesive-Tape-Masking-Tape', 'Masking Tape', 'Masking tape is made of crepe paper that coated with rubber adhesive that could use for sealing , holding and general purpose applications. It’s available in different sizes , widths and designs to meet client’s special requirements. It used in different temperature degrees for painting and car’s spray. and Covering surfaces during spraying or painting. and also Protection of metal , plastic and glasses surfaces .', 'Self Adhesive Tape | Masking Tape use for sealing and holding', 'Masking tape is made of crepe paper that coated with rubber adhesive that could use for sealing , holding and general purpose applications. ', NULL, NULL, NULL),
(9, 10, 'ar', 'الأشرطة-ذاتية-اللصق-شريط-العزل-الكهربائي', 'شرائط العزل الكهربائي', 'شرائط العزل الكهربائي PVC مصنوعة من البولي فينيل كلوريد (spvc) المطلي بمادة لاصقة حساسة للضغط، كما أنه يعتبر مقاومًا جيدًا لدرجات الحرارة والرطوبة والجهد العالي وتطبيقات الحماية. متوفر بأحجام مختلفة. يستخدم فى تطبيقات الاعمال الكهربائية', 'الأشرطة ذاتية اللصق | شريط العزل الكهربائي ', 'شرائط العزل الكهربائي PVC مصنوعة من البولي فينيل كلوريد (spvc) المطلي بمادة لاصقة حساسة للضغط، كما أنه يعتبر مقاومًا جيدًا لدرجات الحرارة والرطوبة والجهد', NULL, NULL, NULL),
(10, 10, 'en', 'Self-Adhesive-Tape-Electrical-Insulating-Tape', 'Electrical Insulating Tape', 'Electrical Insulating Tape PVC insulating tape is made from soft polyvinyl chloride (spvc) which is coated with rubber pressure -sensitive adhesive , it’s also considered good resistant to temperature , moisture , high voltage and protection applications .\r\nIt’s available in different sizes .Usage in Strong tensile strength use in electric work application .', 'Self Adhesive Tape | Electrical Insulating Tape', 'Electrical Insulating Tape PVC insulating tape is made from soft polyvinyl chloride (spvc) which is coated with rubber pressure -sensitive adhesive ', NULL, NULL, NULL),
(11, 12, 'ar', 'الأشرطة-ذاتية-اللصق-شرائط-مزدوجة-الوجهين', 'شرائط مزدوجة الوجهين', 'الشرائط مزدوجة الوجهين مصنوعه ومغلفه بمادة لاصقة مذيبة. يتم استخدامه للزينة والخدمات البريدية. متوفره بأحجام وعرض مختلفة لتلبية لمتطلبات العملاء الخاصة. الاستخدام ملاحظات عامة ، تثبيت العناصر والصور ، تغليف الهدايا والخدمات البريدية.', 'الأشرطة ذاتية اللصق | شرائط مزدوجة الوجهين', 'الشرائط مزدوجة الوجهين مصنوعه ومغلفه بمادة لاصقة مذيبة. يتم استخدامه للزينة والخدمات البريدية. متوفره بأحجام وعرض مختلفة لتلبية لمتطلبات العملاء الخاصة. ', NULL, NULL, NULL),
(12, 12, 'en', 'Self-Adhesive-Tape-Double-Sided-Tape', 'Double Sided Tape', 'Double side tissue tape is made and coated with solvent adhesive . It’s used for decoration and postal services. It’s available in different sizes , widths and designs to meet client’s special requirements. Usage Public notes , fixing items and photos , gift wrapping and postal services .', 'Self Adhesive Tape | Double Sided Tape', 'Double side tissue tape is made and coated with solvent adhesive . It’s used for decoration and postal services. It’s available in different sizes', NULL, NULL, NULL),
(13, 13, 'ar', 'شرائط-ذاتية-اللصق-ملونه', 'شرائط ذاتية اللصق ملونه', 'الشرائط ذاتية اللصق الملونه مصنوعه من أغشية BOPP اللاصقة المائية المصنوعة من الأكريليك ، ويمكن توفيره بألوان عديدة لمساعدة العملاء في عمليات تنظيم وفرز المنتجات اثناء التخزين او النقل متوفر بأحجام وعرض مختلفة لتلبية جميع احتياجات و متطلبات العملاء الخاصة', 'الأشرطة ذاتية اللصق | شرائط ذاتية اللصق ملونه', 'الشرائط ذاتية اللصق الملونه مصنوعه من أغشية BOPP اللاصقة المائية المصنوعة من الأكريليك، ويمكن توفيره بألوان عديدة لمساعدة العملاء في عمليات تنظيم وفرز المنتجات', NULL, NULL, NULL),
(14, 13, 'en', 'Self-Adhesive-Color-Tape', 'Color Tape', 'Color tape is made coated with water based acrylic adhesive BOPP films , its can provided in many colors to help customers in a well-organized operations , also in sorting products in the warehouse .\r\nIt’s available in different sizes &amp; width to meet client’s special requirements .\r\nIt can be used in controlling products and sorting different types in warehouses .', 'Self Adhesive Tape | Self Adhesive Color Tape ', 'Color tape is made coated with water based acrylic adhesive BOPP films , its can provided in many colors to help customers in a well-organized operations', NULL, NULL, NULL),
(15, 14, 'ar', 'الاشرطة-ذاتية-اللصق-المطبوعة', 'الاشرطة ذاتية اللصق المطبوعة', 'يعد استعدام الاشرطة ذاتية اللصق المطبوعة رائعًا لتغليف المنتجات كما انه يستخدم أيضًا كأداة تسويق فعالة منخفضة التكلفة.\r\nهناك العديد من المزايا المكتسبة من خلال استخدام الاشرطة ذاتية اللصق المطبوعة بصرف النظر عن مجرد اداة لتغليف الصناديق والطرود الخاصة بك بشكل آمن ، حيث يعمل التصميم المتسخدم كهوية بصرية تعزز علامتك التجارية أثناء النقل. إنه أيضًا منتج رائع لزيادة الوعي بعلامتك التجارية.', 'الاشرطة ذاتية اللصق | الاشرطة ذاتية اللصق المطبوعة ', 'يعد استعدام الاشرطة ذاتية اللصق المطبوعة رائعًا لتغليف المنتجات كما انه يستخدم أيضًا كأداة تسويق فعالة منخفضة التكلفة.وهناك العديد من المزايا المكتسبة ', NULL, NULL, NULL),
(16, 14, 'en', 'Printed-Self-Adhesive-Tape', 'Printed Self Adhesive Tape', 'Printed Self Adhesive Tape is great for sealing boxes and is also used as an effective low cost Marketing Tool. There are numerous advantages gained by utilizing a custom tape apart from just sealing your boxes securely, the continuous design acts as a visual tamper evident security measure and promotes your brand whilst in transit. It’s also a great product to increase your brand awareness.', 'Self Adhesive Tape | Printed Self Adhesive Tape', 'Printed Self Adhesive Tape is great for sealing boxes and is also used as an effective low cost Marketing Tool. There are numerous advantages ', NULL, NULL, NULL),
(17, 15, 'ar', 'ألومنيوم-فويل', 'الألومنيوم فويل', 'رقائق الألومنيوم أو ورق الألومنيوم هو الألومنيوم مُعد بورق رقيق، بسماكة أقل من 0.2 مل، قد تصل في بعض الأحيان إلى سماكة 6 ميكرومتر، يستخدم لتغليف الأطعمة، إن هذه الرقاقات تكون مرنةً وبسهولة يمكن ثنيها وجعلها تلتف حول الأشياء، تكون الرقاقات بعض الأحيان هشةً لذلك يقام بتدعيمها بمواد أخرى كالبلاستيك والورق العادي لجعلها أكثر فائدة. في القرن العشرين حلت رقاقات الألمنيوم محل الرقاقات القصديرية.', 'عتمان جروب متخصصون فى صناعة ألومنيوم فويل ', 'رقائق الألومنيوم أو ورق الألومنيوم هو الألومنيوم مُعد بورق رقيق، بسماكة أقل من 0.2 مل، قد تصل في بعض الأحيان إلى سماكة 6 ميكرومتر، يستخدم لتغليف الأطعمة', NULL, NULL, NULL),
(18, 15, 'en', 'Aluminum-Foil', 'Aluminum Foil', 'Aluminium foil is aluminium prepared in thin metal leaves with a thickness less than 0.2 mm thinner gauges down to 6 micrometres (0.24 mils) are also commonly used. The foil is pliable, and can be readily bent or wrapped around objects. Thin foils are fragile and are sometimes laminated with other materials such as plastics or paper to make them stronger and more useful.', 'Atman Group specializes in the manufacture of aluminum foil ', 'Aluminium foil is aluminium prepared in thin metal leaves with a thickness less than 0.2 mm thinner gauges down to 6 micrometres (0.24 mils) are also commonly ', NULL, NULL, NULL),
(19, 16, 'ar', 'الومنيوم-فويل-للاستخدام-الصناعى', 'الومنيوم فويل للاستخدام الصناعى', 'يعد العزل أحد أهم مجالات تطبيق رقائق الألومنيوم. يتم استخدامه على سبيل المثال كطبقة عازلة للحرارة لعزل الأنابيب والقنوات.\r\n\r\nبدأ ظهور رقائق الألومنيوم في صناعة التعبئة والتغليف في وقت مبكر من بداية القرن العشرين. في وقت مبكر من عام 1910 ، كان من الممكن إنتاج ما يصل إلى 10 ميكرولتر (1/100 مم) رقائق ألمنيوم سميكة وتصفيحها بالورق. أدت التحسينات التكنولوجية إلى تطور سريع من استخدام الألمنيوم لتغليف الشوكولاتة إلى تصنيع علب المشروبات ، وكبسولات القهوة ، وصواني الشواء وأغطية الزجاجات.', 'الألومنيوم فويل | الومنيوم فويل للاستخدام الصناعى', 'يعد العزل أحد أهم مجالات تطبيق رقائق الألومنيوم. يتم استخدامه على سبيل المثال كطبقة عازلة للحرارة لعزل الأنابيب والقنوات.', NULL, NULL, NULL),
(20, 16, 'en', 'Aluminium-foil-for-Industry-Use', 'Aluminium foil for Industry Use', 'One of the most important fields of application of aluminum foil is insulation. It is used for example as a heat-insulating layer for the insulation of pipes and ducts.\r\n\r\nThe rise of aluminum foil in the packaging industry began as early as the beginning of the 20th century. As early as 1910, it was possible to produce up to 10 μ (1/100 mm) thick aluminum foils and laminate them with paper. Technological improvements have led to a rapid development from the use of aluminum as chocolate packaging to the manufacture of aluminum beverage cans, coffee capsules, grill trays and bottle caps.', 'Aluminium Foil | Aluminium foil for Industry Use', 'One of the most important fields of application of aluminum foil is insulation. It is used for example as a heat-insulating layer for the insulation of pipes ', NULL, NULL, NULL),
(21, 17, 'ar', 'الومنيوم-فويل-استخدام-منزلى', 'الومنيوم فويل استخدام منزلى', 'مثالي لاحتياجات الطهي اليومية وسهولة التنظيف آمن للطعام وخالي من أي مواد ضارة.يمكننا توفير علامات تجارية مختلفة للمنتجات النهائية لتلبية متطلبات جميع العملاء.\r\nالاستخدامات للمنزل والمقهى والمطعم. يمكن استخدامها في تغليف الوجبات السريعة.\r\nاستخدم أيضًا في تطبيق الطهي لحماية سطح الفرن.', 'الومنيوم فويل | الومنيوم فويل استخدام منزلى', 'مثالي لاحتياجات الطهي اليومية وسهولة التنظيف غلاف رقائق الطعام آمن للطعام وخالي من أي مواد ضارة.يمكننا توفير علامات تجارية مختلفة للمنتجات ', NULL, NULL, NULL),
(22, 17, 'en', 'Aluminium-foil-for-House-Hold', 'Aluminium foil for House Hold', 'Perfect for everyday cooking needs and easy clean up\r\nThe food grade foil wrap is food-safe, free of any harmful substances.\r\nwe can supply different brands for finished products to meet all clients requirement .\r\nUsages for house , cafe and restaurant . can use in fast food packing . \r\nAlso use in cook application for oven surface protection .', 'Aluminium Foil | Aluminium foil for House Hold', 'We can supply finish goods for aluminum foil for house and home use , as need in wrap food in homes.we can supply different brands for finished products to ', NULL, NULL, NULL),
(23, 18, 'ar', 'Food-and-beverage', 'الأغذية والمشروبات', 'صناعة الأغذية والمشروبات كبيرة ومتنوعة ومليئة بالآلات المتخصصة. إنها واحدة من أقدم الصناعات على هذا الكوكب ، لكنها لا تزال مليئة بالابتكار.\r\n\r\nواستجابةً لحاجة الصناعة إلى هذا التطور السريع ، واهتمامها المتزايد بسلامة الأغذية وأمنها ، نقدم الحلول التي تلبي هذه الاحتياجات الحالية.\r\n\r\nتوفر شركة عتمان جروب مجموعة كبيرة من المنتجات التى تستخدم فى مجال الأطعمة والمشروبات المعبأة في حياتنا اليومية. وتستخدم هذه المنتجات في حياتنا اليومية ويمكننا العثور عليها في كل مكان الآن.', 'عتمان جروب قسم المنتجات الخاصة بالأغذية والمشروبات', 'صناعة الأغذية والمشروبات كبيرة ومتنوعة ومليئة بالآلات المتخصصة. إنها واحدة من أقدم الصناعات على هذا الكوكب ، لكنها لا تزال مليئة بالابتكار.', NULL, NULL, NULL),
(24, 18, 'en', 'Food-and-beverage', 'Food And Beverage', 'The Food and Beverage Industry is large, diverse, and full of specialized machinery. It’s one of the oldest industries on the planet, but still full of innovation. \r\n\r\nIn response to industry’s need to comply with regulations of all sorts, and an increasing concern for food safety and security, we provide the solutions that meet current needs.\r\n\r\nItems used in smart solution for packed food and beverage in our daily life .These items use in our daily life we can find them every where now a day .', 'Etman Group Food and Beverage Products Division ', 'The Food and Beverage Industry is large, diverse, and full of specialized machinery. It’s one of the oldest industries on the planet, but still full ', NULL, NULL, NULL),
(25, 19, 'ar', 'الاسترتش-الغذائى', 'الاسترتش الغذائى', 'إن أهم دور يلعبه الاسترتش الغذائى في تغليف المواد الغذائية هو الحماية والحفظ. يمكن أن يمنع الاسترتش الغذائى الطعام من الهلاك ، ويطيل عمره الافتراضي ، ويحافظ على جودة الطعام. يوفر الاسترتش الغذائى بشكل عام الحماية للأغذية من ثلاثة جوانب: المواد الكيميائية (الغازات والرطوبة والضوء) والبيولوجية (الكائنات الحية الدقيقة والحشرات والحيوانات) والفيزيائية (الأضرار الميكانيكية). بالإضافة إلى حماية الأغذية وحفظها ، يمكن للاسترتش الغذائى أيضًا أن يقلل من هدر الطعام ، ويسهل عمليات التوزيع', 'الاسترتش الغذائى يستخدم في تغليف المواد الغذائية بغرض الحماية والحفظ', 'إن أهم دور يلعبه الاسترتش الغذائى في تغليف المواد الغذائية بغرض الحماية والحفظ. يمكن أن يمنع الاسترتش الغذائى الطعام من الهلاك', NULL, NULL, NULL),
(26, 19, 'en', 'Cling-Warp', 'Cling Warp', 'The most important role Cling Warp plays in food packaging is protection and preservation. Cling Warp can prevent food from perishing, extend its shelf-life, and maintain the quality of food. Cling Warp generally provides protection for food from three aspects: chemical (gases, moisture, and light), biological (microorganisms, insects and animals), and physical (mechanical damage). In addition to food protection and preservation, Cling Warp can also reduce food waste, tag food information, ease the distribution processes, and increase product visibility and microwavability', 'Cling Warp is used in food packaging for the purpose of protection', 'The most important role Cling Warp plays in food packaging is protection and preservation. Cling Warp can prevent food from perishing', NULL, NULL, NULL),
(27, 23, 'ar', 'مستلزمات-الهدايا', 'مستلزمات الهدايا', 'الهدايا هي رمز للسعادة والاحتفال. إنها بمثابة إظهار لمشاعرنا ويمكن أن تكون لفتة ذات مغزى تجاه شخص نقدره.\r\nعتمان جروب تمتلك الخبرة الكافية لكى تكون هى الشركة الاولى فى توفير جميع المستلزمات الخاصة بتغليف الهداية بداية من ورق الهدايا مرورا بشنط الهدايا والكوريشة الخ', 'عتمان جروب قسم منتجات الخاصة بمستلزمات الهدايا', 'عتمان جروب تمتلك الخبرة الكافية لكى تكون هى الشركة الاولى فى توفير جميع المستلزمات الخاصة بتغليف الهداية بداية من ورق الهدايا مرورا بشنط الهدايا والكوريشة الخ ', NULL, NULL, NULL),
(28, 23, 'en', 'Decorative-Strips', 'Gift Accessories', 'Gifts are a symbol of happiness and celebration. They act as a demonstration of our feelings and can be a meaningful gesture towards someone that we value. \r\n\r\nEtman Group has sufficient experience to be the first company in providing all the requirements for gift wrapping, starting from gift paper through gift bags and cores, etc.', 'Etman Group Products section for Decorative Strips  ', 'Etman Group has sufficient experience to be the first company in providing all the requirements for gift wrapping, starting from gift paper through gift bags', NULL, NULL, NULL),
(29, 24, 'ar', 'مستلزمات-الهدايا-شرائط-الزينة', 'شرائط الزينة', 'عتمان جروب لديها الجودة التي تبحث عنها. من خلال مجموعة كبيرة من الاختيارات ، يمكنك استكشاف تشكيلتنا من أفضل المنتجات. ابحث عن شرائط الزينة ستجد انها من اهم المنتجات الشائع استخدمها بصورة يومية\r\n\r\nعتمان جروب هي مصنع محترف ومصدر للشريط وتمتلك أكثر من 40 عامًا من الخبرة في مجال صناعة شرائط الزينة . مع توفر العمالة الماهرة والمواد الخام المنتجة ذاتيًا ، سيكون التسليم السريع والجودة المستقرة أمرًا سهلاً في شركتنا.\r\n\r\nلدينا تشكيلة كبيرة من منتجات شرائط الزينة ، يمكن استخدامها لتزيين أي منتج. لحفلات الزفاف ، والكريسماس ، وأعياد الميلاد ، والخطوبة ، وعيد الأم ، والتهاني ، وديكورات المهرجانات ، والحرف اليدوية ، والهدايا ، وإكسسوارات الألعاب ، إلخ.', 'مستلزمات الهدايا | منتجات شرائط الزينة بجميع انواعها ', 'عتمان جروب هي مصنع محترف ومصدر للشريط وتمتلك أكثر من 40 عامًا من الخبرة في مجال صناعة شرائط الزينة . مع توفر العمالة الماهرة والمواد الخام المنتجة ذاتيًا ', NULL, NULL, NULL),
(30, 24, 'en', 'Gift-Accessories-Ribbon', 'Ribbon', 'Etman Group has the selection and quality you’re looking for. With a collection that includes ribbons in every material,  you can explore our assortment of top product. Find ribbons you’ll find an excuse to use every day ! \r\n\r\nEtman Group  is a professional factory manufacturer &amp; exporter of ribbon More than 40 years experience in handmade ribbon . With skilled workers and self-produced raw materials, fast delivery and stable quality is easy in our company. \r\n\r\nWe have more than styles of ribbon, It can be used for decoration of any product. For wedding, Christmas, Birthday, Engagement,Mother’s day, Congratulations, and other festival decoration, Handcraft, gift and premiums, packing ornament and toy’s accessories etc.', 'Gift Accessories Decorative ribbon products of all kinds ', 'Etman Group is a professional factory manufacturer & exporter of ribbon More than 40 years experience in handmade ribbon .', NULL, NULL, NULL),
(31, 25, 'ar', 'ورق-الهدايا', 'ورق الهدايا', 'ورق الهدايا من المنتجات التى يجب الاحتفاظ به في منزلك لجميع احتياجات تغليف الهدايا - أو لف مجموعة متنوعة من العناصر. تم انتجها من خامات عالية الجدوة ، سميكة ولا يمكن تمزقها بسهولة. يمكن استخدامه لتزيين أي منتج. لحفلات الزفاف ، والكريسماس ، وأعياد الميلاد ، والخطوبة ، وعيد الأم ، والتهاني ، والديكورات الأخرى للمهرجانات ، والحرف اليدوية ، والهدايا والأقساط ، وزخرفة التعبئة ، وإكسسوارات الألعاب ، إلخ.', 'مستلزمات الهدايا | جميع منتجات ورق الهدايا من عتمان جروب ', 'ورق الهدايا من المنتجات التى يجب الاحتفاظ به في منزلك لجميع احتياجات تغليف الهدايا - أو لف مجموعة متنوعة من العناصر. تم انتجها من خامات عالية الجدوة ', NULL, NULL, NULL),
(32, 25, 'en', 'Gift-Accessories-Gift-Paper', 'Gift Paper', 'Gift Paper is a must-have to keep in your home for all your gift wrapping needs – use it for gift bags or wrapping a variety of items. Created with high-quality paper materials, thick and not easily tear or rip. Item came with shrink film to prevent wrapping paper from scratches and reduce dust.It can be used for decoration of any product. For wedding, Christmas, Birthday, Engagement,Mother’s day, Congratulations, and other festival decoration, Handcraft, gift and premiums, packing ornament and toy’s accessories etc.', 'Gift Accessories |  All gift paper products from Etman Group', 'Gift Paper is a must-have to keep in your home for all your gift wrapping needs use it for gift bags or wrapping a variety of items. Created with high-quality', NULL, NULL, NULL),
(33, 26, 'ar', 'مستلزمات-الهدايا-الكوريشة', 'الكوريشة', 'تستخدم ورق الكوريشة عالي الجودة الخاص بنا لإنشاء باقة زهور جميلة مثالي لحفلات الزفاف والذكرى السنوية واحتفالات أعياد الميلاد وحفلات التخرج وحفلات استقبال المولود الجديد وحفلات الخطوبة والمزيد!', 'مستلزمات الهدايا | جميع انواع منتجات الكوريشة المستوردة ', 'تستخدم ورق الكوريشة عالي الجودة الخاص بنا لإنشاء باقة زهور جميلة مثالي لحفلات الزفاف والذكرى السنوية واحتفالات أعياد الميلاد وحفلات التخرج ', NULL, NULL, NULL),
(34, 26, 'en', 'Gift-Accessories-Crepe-Paper', 'Crepe Paper', 'Premium Quality Crepe Paper Rolls,Crepe Paper flowers are a fabulous alternative to fresh flowers! Use our quality Crepe Paper to create a beautiful floral bouquet that will last for years to come. Perfect for weddings, anniversaries, birthday celebrations, graduations, baby showers, engagement parties, and more !', 'Gift Accessories | All type of imported Crepe Paper products ', 'Premium Quality Crepe Paper Rolls,Crepe Paper flowers are a fabulous alternative to fresh flowers! Use our Crepe Paper to create a beautiful floral bouquet ', NULL, NULL, NULL),
(35, 36, 'ar', 'الأشرطة-ذاتية-اللصق-ليزير-تيب', 'ليزير تيب', 'ليزير تيب يستخدام فى اعمال التغليف وكذلك فى الديكورات والاعمال الفنية و الحفلات وكذلك الاستخدامات المكتبية يمكننا توفير 6 ألوان مختلفة لتلبية طلب العميل.', 'الأشرطة ذاتية اللصق | ليزير تيب يستخدام فى اعمال التغليف والديكور ', 'ليزير تيب يستخدام فى اعمال التغليف وكذلك فى الديكورات والاعمال الفنية و الحفلات وكذلك الاستخدامات المكتبية يمكننا توفير 6 ألوان مختلفة لتلبية طلب العميل.', NULL, NULL, NULL),
(36, 36, 'en', 'Self-Adhesive-Tape-Laser-Tape', 'Laser Tape', 'Laser Tape use for sealing and decorative Use in parties and stationery we can supply 6 different colors to meet client request.', 'Self Adhesive Tape | LASER Tape Use in parties and stationery ', 'Laser Tape use for sealing and decorative Use in parties and stationery we can supply 6 different colors to meet client request.', NULL, NULL, NULL),
(37, 37, 'ar', 'جامبو-رول', 'جامبو رول', 'شرائط BOPP الجامبو رول هي منتج نصف نهائى يستخدمه المصنعون للشرائط ذاتية اللصق عن طريق اعادة تقطيعه على الماكينات المجهزة لذلك مع منتجاتنا نضمن افضل جودة تساعدك على تقديم افضل منتج نهائى يستطيع المنافسة فى الاسواق المحلية والعالمية \r\n\r\nيمكننا توريد جميع أنواع الشرائط ذاتية اللصق BOPP بسماكات وألوان مختلفة ، عادي / مطبوع في رولات جامبو من جميع العروض والسمك.', 'الأشرطة ذاتية اللصق | جامبو رول | عتمان جروب', 'شرائط BOPP الجامبو رول هي منتج نصف نهائى يستخدمه المصنعون للشرائط ذاتية اللصق عن طريق اعادة تقطيعه على الماكينات المجهزة لذلك مع منتجاتنا نضمن افضل جودة', NULL, NULL, NULL),
(38, 37, 'en', 'Jumbo-Roll', 'Jumbo Roll', 'BOPP jumbo roll tape is Semi-finished product for Semi manufacturers slitting it into smaller rolls on the slitting machine. With our products, You can assure your brand quality stability.\r\n\r\nWe can supply all kinds of BOPP Self adhesive tape in various thicknesses, colors, plain/printed in Jumbo rolls of all widths and thickness.', 'Jumbo Roll | Self Adhesive Tape | Etman Group', 'BOPP jumbo roll tape is Semi-finished product for Semi manufacturers slitting it into smaller rolls on the slitting machine.We can supply all kinds of BOPP', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_def_photos`
--

CREATE TABLE `config_def_photos` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_def_photos`
--

INSERT INTO `config_def_photos` (`id`, `cat_id`, `photo`, `photo_thum_1`, `photo_thum_2`, `postion`, `created_at`, `updated_at`) VALUES
(1, 'logo', 'images/def-photo/logo-N7MXfyFq7i.webp', NULL, NULL, 6, '2023-08-16 09:18:40', '2023-08-16 11:24:00'),
(3, 'project', 'images/def-photo/project-2mW1dPGqA4.webp', 'images/def-photo/project-4CIZMONAWn.webp', NULL, 1, '2023-08-16 09:18:40', '2023-08-16 11:21:37'),
(4, 'blog', 'images/def-photo/blog-0i93d20McM.webp', 'images/def-photo/blog-ja40gxZ7NU.webp', NULL, 2, '2023-08-16 09:18:40', '2023-08-16 11:29:40'),
(5, 'district', 'images/def-photo/district-KV7ho9poco.webp', 'images/def-photo/district-vYTx3dGPKL.webp', NULL, 3, '2023-08-16 09:18:40', '2023-08-16 11:26:38'),
(6, 'units', 'images/def-photo/units-IjgBIWg5fb.webp', 'images/def-photo/units-SUapFskARy.webp', NULL, 4, '2023-08-16 09:18:40', '2023-08-16 11:27:27'),
(7, 'developer', 'images/def-photo/developer-5ZTk6EyQOs.webp', 'images/def-photo/developer-b7xM42SSYe.webp', NULL, 0, '2023-08-16 11:28:03', '2023-08-16 11:28:03');

-- --------------------------------------------------------

--
-- Table structure for table `config_settings`
--

CREATE TABLE `config_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `web_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `web_status` int(11) NOT NULL DEFAULT 1,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_api` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_settings`
--

INSERT INTO `config_settings` (`id`, `web_url`, `web_status`, `logo`, `favicon`, `phone_num`, `whatsapp_num`, `facebook`, `youtube`, `twitter`, `instagram`, `google_api`, `created_at`, `updated_at`) VALUES
(1, '#', 1, '', '', '01221563252', '201221563252', '#', '#', '#', '#', '#', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_setting_translations`
--

CREATE TABLE `config_setting_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closed_mass` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_setting_translations`
--

INSERT INTO `config_setting_translations` (`id`, `setting_id`, `locale`, `name`, `g_title`, `g_des`, `closed_mass`) VALUES
(1, 1, 'ar', 'اسم الموقع يكتب هنا', 'عنوان الصفحة يكتب هنا', 'وصف الصفحة يكتب هنا', 'رسالة الاغلاق تكتب هنا'),
(2, 1, 'en', 'The name of the site is written here', 'The title of the site is written here', 'The description of the site is written here', 'The closed mass of the site is written here ');

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filters`
--

CREATE TABLE `config_upload_filters` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `convert_state` int(11) NOT NULL DEFAULT 1,
  `quality_val` int(11) NOT NULL DEFAULT 85,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#ffffff',
  `greyscale` int(11) NOT NULL DEFAULT 0,
  `flip_state` int(11) NOT NULL DEFAULT 0,
  `flip_v` int(11) NOT NULL DEFAULT 0,
  `blur` int(11) NOT NULL DEFAULT 0,
  `blur_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `pixelate` int(11) NOT NULL DEFAULT 0,
  `pixelate_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '5',
  `text_state` int(11) NOT NULL DEFAULT 0,
  `text_print` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_opacity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_state` int(11) NOT NULL DEFAULT 0,
  `watermark_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filters`
--

INSERT INTO `config_upload_filters` (`id`, `name`, `type`, `convert_state`, `quality_val`, `new_w`, `new_h`, `canvas_back`, `greyscale`, `flip_state`, `flip_v`, `blur`, `blur_size`, `pixelate`, `pixelate_size`, `text_state`, `text_print`, `font_size`, `font_path`, `font_color`, `font_opacity`, `text_position`, `watermark_state`, `watermark_img`, `watermark_position`, `state`, `created_at`, `updated_at`) VALUES
(1, 'NoEdit', 1, 1, 85, 100, 100, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-08-21 20:12:15', '2023-08-21 20:12:15'),
(2, 'DefPhoto', 4, 1, 85, 800, 420, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-08-21 20:12:15', '2023-08-21 20:12:15'),
(3, 'FavIcon', 4, 1, 85, 40, 40, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-08-21 20:12:15', '2023-08-21 20:12:15'),
(4, 'Amenity', 4, 1, 85, 80, 80, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-08-21 20:12:15', '2023-08-21 20:12:15'),
(5, 'PhotoGallery', 4, 1, 85, 1024, 768, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-08-21 20:12:15', '2023-08-21 20:12:15');

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filter_sizes`
--

CREATE TABLE `config_upload_filter_sizes` (
  `id` int(10) UNSIGNED NOT NULL,
  `filter_id` int(10) UNSIGNED NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `get_more_option` int(11) NOT NULL DEFAULT 0,
  `get_add_text` int(11) NOT NULL DEFAULT 0,
  `get_watermark` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filter_sizes`
--

INSERT INTO `config_upload_filter_sizes` (`id`, `filter_id`, `type`, `new_w`, `new_h`, `canvas_back`, `get_more_option`, `get_add_text`, `get_watermark`) VALUES
(1, 2, 4, 500, 335, NULL, 0, 0, 0),
(2, 4, 4, 40, 40, NULL, 0, 0, 0),
(3, 5, 4, 800, 600, '#ffffff', 0, 0, 0),
(4, 5, 4, 320, 240, '#ffffff', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `meta_tags`
--

CREATE TABLE `meta_tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `meta_tags`
--

INSERT INTO `meta_tags` (`id`, `cat_id`, `created_at`, `updated_at`) VALUES
(1, 'home', '2023-08-16 09:18:40', '2023-08-16 09:18:40'),
(2, 'developer', '2023-08-16 11:16:16', '2023-08-16 11:16:16'),
(3, 'blog', '2023-08-16 11:30:42', '2023-08-16 11:30:42'),
(4, 'contact-us', '2023-08-16 11:32:36', '2023-08-16 11:32:36');

-- --------------------------------------------------------

--
-- Table structure for table `meta_tag_translations`
--

CREATE TABLE `meta_tag_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `meta_tag_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_h1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `breadcrumb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `meta_tag_translations`
--

INSERT INTO `meta_tag_translations` (`id`, `meta_tag_id`, `locale`, `g_title`, `g_des`, `body_h1`, `breadcrumb`) VALUES
(1, 1, 'ar', 'الصفحة الرئيسة', 'وصف الصفحة الرئيسية', 'الصفحة الرئيسية H1', 'وسام الصفحة الرئيسية'),
(2, 1, 'en', 'Home Page', 'Home Description ', 'Home h1 tag', 'Home breadcrumb'),
(3, 2, 'ar', 'المطورين', 'المطورين', 'المطورين', 'المطورين'),
(4, 2, 'en', 'Developer', 'Developer', 'Developer', 'Developer'),
(5, 3, 'ar', 'المقالات', 'المقالات', 'المقالات', 'المقالات'),
(6, 3, 'en', 'Blog', 'Blog', 'Blog', 'Blog'),
(7, 4, 'ar', 'اتصل بنا', 'اتصل بنا', 'اتصل بنا', 'اتصل بنا'),
(8, 4, 'en', 'Contact Us', 'Contact Us', 'Contact Us', 'Contact Us');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(127, '2014_10_12_000000_create_users_table', 1),
(128, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(129, '2014_10_12_100000_create_password_resets_table', 1),
(130, '2019_08_19_000000_create_failed_jobs_table', 1),
(131, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(132, '2023_06_24_105531_create_settings_table', 1),
(133, '2023_06_24_144232_create_setting_translations_table', 1),
(134, '2023_06_25_165355_create_meta_tags_table', 1),
(135, '2023_06_25_201026_create_meta_tag_translations_table', 1),
(136, '2023_06_29_193744_create_def_photos_table', 1),
(137, '2023_06_29_235416_create_upload_filters_table', 1),
(138, '2023_07_03_115945_create_upload_filter_sizes_table', 1),
(139, '2023_07_12_171931_create_permission_tables', 1),
(140, '2023_07_14_112208_add_names_roles_table', 1),
(141, '2023_07_14_115125_add_names_permissions_table', 1),
(142, '2023_07_16_155230_create_categories_table', 1),
(143, '2023_07_16_155651_create_category_translations_table', 1),
(144, '2023_08_21_093710_create_category_tables_table', 1),
(145, '2023_08_21_093808_create_category_table_translations_table', 1),
(146, '2023_08_21_170942_create_attribute_tables_table', 1),
(147, '2023_08_21_170949_create_attribute_table_translations_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(2, 'App\\Models\\User', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `cat_id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'users_view', 'عرض', 'View', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(2, 1, 'users_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(3, 1, 'users_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(4, 1, 'users_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(5, 2, 'roles_view', 'عرض', 'View', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(6, 2, 'roles_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(7, 2, 'roles_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(8, 2, 'roles_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(9, 2, 'roles_update_permissions', 'تعديل صلاحيات المجموعة', 'Roles Update Permissions', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(10, 3, 'permissions_view', 'عرض', 'View', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(11, 3, 'permissions_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(12, 3, 'permissions_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(13, 3, 'permissions_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(14, 4, 'amenity_view', 'عرض', 'View', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(15, 4, 'amenity_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(16, 4, 'amenity_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(17, 4, 'amenity_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(18, 5, 'adminlang_view', 'عرض ملفات لغة التحكم', 'View Admin Lang', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(19, 5, 'adminlang_edit', 'تعديل ملفات لغة التحكم', 'Edit Admin Lang', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(20, 5, 'weblang_view', 'عرض', 'View', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(21, 5, 'weblang_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(22, 6, 'config_section', 'عرض الاعدادات', 'Setting View', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(23, 6, 'website_config', 'اعدادات الموقع', 'Web Site Setting', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(24, 7, 'meta_view', 'عرض', 'View', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(25, 7, 'meta_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(26, 7, 'meta_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(27, 7, 'meta_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(28, 8, 'defPhoto_view', 'عرض', 'View', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(29, 8, 'defPhoto_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(30, 8, 'defPhoto_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(31, 8, 'defPhoto_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(32, 9, 'upFilter_view', 'عرض', 'View', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(33, 9, 'upFilter_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(34, 9, 'upFilter_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(35, 9, 'upFilter_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(36, 10, 'category_view', 'عرض', 'View', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(37, 10, 'category_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(38, 10, 'category_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(39, 10, 'category_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(40, 10, 'category_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(41, 11, 'post_view', 'عرض', 'View', 'web', '2023-08-21 17:12:13', '2023-08-21 17:12:13'),
(42, 11, 'post_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(43, 11, 'post_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(44, 11, 'post_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(45, 11, 'post_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(46, 12, 'location_view', 'عرض', 'View', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(47, 12, 'location_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(48, 12, 'location_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(49, 12, 'location_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(50, 12, 'location_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(51, 13, 'developer_view', 'عرض', 'View', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(52, 13, 'developer_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(53, 13, 'developer_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(54, 13, 'developer_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(55, 13, 'developer_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(56, 14, 'project_view', 'عرض', 'View', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(57, 14, 'project_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(58, 14, 'project_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(59, 14, 'project_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(60, 14, 'project_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(61, 15, 'unit_view', 'عرض', 'View', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(62, 15, 'unit_add', 'اضافة', 'Add', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(63, 15, 'unit_edit', 'تعديل', 'Edit', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(64, 15, 'unit_delete', 'حذف', 'Delete', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(65, 15, 'unit_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'ادمن كامل الصلاحيات', 'Full Admin Permission ', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(2, 'editor', 'محرر', 'editor', 'web', '2023-08-21 17:12:14', '2023-08-21 17:12:14');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(22, 1),
(23, 1),
(24, 1),
(25, 1),
(26, 1),
(27, 1),
(28, 1),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(33, 1),
(34, 1),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(45, 1),
(46, 1),
(47, 1),
(48, 1),
(49, 1),
(50, 1),
(51, 1),
(52, 1),
(53, 1),
(54, 1),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(60, 1),
(61, 1),
(62, 1),
(63, 1),
(64, 1),
(65, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `photo`, `photo_thum_1`, `roles_name`, `status`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Hany Darwish ', 'test@test.com', NULL, NULL, NULL, '[\"admin\"]', 1, NULL, '$2y$10$CufKHdGHNyNkM/dCWkCFteZMzmkIP5.aABkeFUANuqq5ZjFj1cBCq', NULL, '2023-08-21 17:12:14', '2023-08-21 17:12:14'),
(2, 'Sub Admin  ', 'subadmin@test.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$6Yfpz2KSjnFuzOnKxaIYMu8Q3kLCLMxT4RrGqZMsVsTX5.ESgGiXq', NULL, '2023-08-21 17:12:15', '2023-08-21 17:12:15'),
(3, 'Editor', 'editor@test.com', NULL, NULL, NULL, '[\"editor\"]', 1, NULL, '$2y$10$HFTI9jVaNTt83nJWO3iWPOZGa/etLRxdqXG7d10mIKWajkqhEJC3a', NULL, '2023-08-21 17:12:15', '2023-08-21 17:12:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attribute_tables`
--
ALTER TABLE `attribute_tables`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attribute_table_translations`
--
ALTER TABLE `attribute_table_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `attribute_table_translations_attribute_id_locale_unique` (`attribute_id`,`locale`),
  ADD KEY `attribute_table_translations_locale_index` (`locale`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_tables`
--
ALTER TABLE `category_tables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_tables_category_id_foreign` (`category_id`);

--
-- Indexes for table `category_table_translations`
--
ALTER TABLE `category_table_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_table_translations_category_table_id_locale_unique` (`category_table_id`,`locale`),
  ADD KEY `category_table_translations_locale_index` (`locale`);

--
-- Indexes for table `category_translations`
--
ALTER TABLE `category_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_translations_category_id_locale_unique` (`category_id`,`locale`),
  ADD UNIQUE KEY `category_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `category_translations_locale_index` (`locale`);

--
-- Indexes for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_settings`
--
ALTER TABLE `config_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_setting_translations_setting_id_locale_unique` (`setting_id`,`locale`),
  ADD KEY `config_setting_translations_locale_index` (`locale`);

--
-- Indexes for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `config_upload_filter_sizes_filter_id_foreign` (`filter_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `meta_tags`
--
ALTER TABLE `meta_tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `meta_tags_cat_id_unique` (`cat_id`);

--
-- Indexes for table `meta_tag_translations`
--
ALTER TABLE `meta_tag_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `meta_tag_translations_meta_tag_id_locale_unique` (`meta_tag_id`,`locale`),
  ADD KEY `meta_tag_translations_locale_index` (`locale`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attribute_tables`
--
ALTER TABLE `attribute_tables`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `attribute_table_translations`
--
ALTER TABLE `attribute_table_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `category_tables`
--
ALTER TABLE `category_tables`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `category_table_translations`
--
ALTER TABLE `category_table_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `category_translations`
--
ALTER TABLE `category_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `config_settings`
--
ALTER TABLE `config_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `meta_tags`
--
ALTER TABLE `meta_tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `meta_tag_translations`
--
ALTER TABLE `meta_tag_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attribute_table_translations`
--
ALTER TABLE `attribute_table_translations`
  ADD CONSTRAINT `attribute_table_translations_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attribute_tables` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `category_tables`
--
ALTER TABLE `category_tables`
  ADD CONSTRAINT `category_tables_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `category_table_translations`
--
ALTER TABLE `category_table_translations`
  ADD CONSTRAINT `category_table_translations_category_table_id_foreign` FOREIGN KEY (`category_table_id`) REFERENCES `category_tables` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `category_translations`
--
ALTER TABLE `category_translations`
  ADD CONSTRAINT `category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD CONSTRAINT `config_setting_translations_setting_id_foreign` FOREIGN KEY (`setting_id`) REFERENCES `config_settings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD CONSTRAINT `config_upload_filter_sizes_filter_id_foreign` FOREIGN KEY (`filter_id`) REFERENCES `config_upload_filters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `meta_tag_translations`
--
ALTER TABLE `meta_tag_translations`
  ADD CONSTRAINT `meta_tag_translations_meta_tag_id_foreign` FOREIGN KEY (`meta_tag_id`) REFERENCES `meta_tags` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
